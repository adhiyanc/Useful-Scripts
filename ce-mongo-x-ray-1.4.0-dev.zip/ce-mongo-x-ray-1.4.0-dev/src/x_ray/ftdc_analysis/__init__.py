"""MongoDB FTDC analysis package."""
