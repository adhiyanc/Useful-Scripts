"""Tests for FTDC analysis."""
